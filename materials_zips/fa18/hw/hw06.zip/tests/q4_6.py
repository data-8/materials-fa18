test = {
  'name': 'Question 4_6',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> # It looks like your other_statistic array is empty!
          >>> len(other_statistic) != 0
          True
          >>> len(other_statistic) == 5000
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
