test = {
  'name': 'Question 3.5',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> minnesota_data.num_rows == 9423
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
