test = {
  'name': 'Question 4.2.4',
  'points': 1,
  'suites': [
    {
      'cases': [
        {
          'code': r"""
          >>> sorted(summed_mn_hazard_data) == ['Condition', 'Died sum', 'Hazard Rate', 'Participated sum']
          True
          """,
          'hidden': False,
          'locked': False
        }
      ],
      'scored': True,
      'setup': '',
      'teardown': '',
      'type': 'doctest'
    }
  ]
}
